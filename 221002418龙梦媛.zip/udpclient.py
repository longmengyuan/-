import socket
#接收端需要输入接受文件的绝对路径才能收到文件
# 设置接收端IP、端口和保存路径
recv_ip = '192.168.204.18'
recv_port = 7777
save_path = input("请输入要保存接收的文件的绝对路径：")

# 创建UDP套接字
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind((recv_ip, recv_port))#绑定了接收端的IP地址和端口号，表示监听指定的IP地址和端口号

# 接收文件数据，用recvfrom的方法，第一个参数是缓冲区大小，第二个参数是发送数据的客户端地址
file_text, addr = server_socket.recvfrom(1024*1024)

# 保存接收的文件，并且需要指定写模式和UTF-8编码，因为文件的数据来源于传输的二进制数据文件需要解码
with open(save_path, 'w', encoding='utf-8') as f:
    f.write(file_text.decode('utf-8'))

# 发送确认信息，表示接收完毕
server_socket.sendto("OK".encode(), addr)

# 关闭套接字
server_socket.close()