import socket
#C语言写代码编译的时候总是缺库，用不了
#不用绝对路径发送不了文件，测试的时候用的是windows系统，端口不同，接受文件的位置不一样，发送端需要输入接收端的IP地址和端口号以及传输的文件的绝对路径
# 设置发送端IP、端口和文件路径
send_ip = '192.168.204.18'
send_port = 6666
file_path = input("请输入要传输的文件的绝对路径：")

# 将文件数据读入到变量中
with open(file_path, encoding='utf-8') as f:
    file_text = f.read()
# 创建UDP套接字
client_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)#SOCK——DGRAM指定使用UDP协议

# 设置接收端IP和端口
recv_ip = input("请输入接收方IP地址：")
recv_port = int(input("请输入接收方端口号："))

# 发送文件数据，参数包括发送的文件数据，接收端IP和端口号，先把数据编码成二进制
client_socket.sendto(file_text.encode('utf-8'), (recv_ip, recv_port))

# 接收回传的确认信息，第一个参数是缓冲区大小，第二个是发送数据的服务器地址
recv_data, addr = client_socket.recvfrom(1024)
if recv_data.decode() == "OK":
    print("文件传输成功！")
else:
    print("文件传输失败！")

# 关闭套接字
client_socket.close()